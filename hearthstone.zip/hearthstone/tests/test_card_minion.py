import unittest
from game.card.Minion import Minion


class CardMinionTestCase(unittest.TestCase):
    def setUp(self):
        self.minion = Minion.random()

    def test_init(self):
        minion = Minion(cost=1, attack=2, hp=3)
        self.assertEqual(minion.cost, 1)
        self.assertEqual(minion.attack, 2)
        self.assertEqual(minion.current_hp, 3)
        self.assertEqual(minion.max_hp, 3)
        self.assertFalse(minion.is_awake)

    def test_damage(self):
        minion = Minion(cost=1, attack=2, hp=3)

        minion.damage(2)
        self.assertEqual(minion.current_hp, 1)

        minion.damage(2)
        self.assertEqual(minion.current_hp, 0)

    def test_heal(self):
        minion = Minion(cost=1, attack=2, hp=3)
        minion.damage(2)

        minion.heal(1)
        self.assertEqual(minion.current_hp, 2)

        minion.heal(2)
        self.assertEqual(minion.current_hp, 3)

    def test_awake(self):
        self.assertFalse(self.minion.is_awake)
        self.minion.awake()
        self.assertTrue(self.minion.is_awake)
