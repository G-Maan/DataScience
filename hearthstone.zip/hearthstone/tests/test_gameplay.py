import unittest

import game.const as const
from game.Game import Game
from game.Player import Player


class MCTSTestCase(unittest.TestCase):
    def setUp(self):
        self.p1 = Player()
        self.p2 = Player()
        self.game = Game(self.p1, self.p2)

    def test_change_player(self):
        self.assertIsNone(self.game.current_player)

        self.game.change_player()
        self.assertEqual(self.game.current_player, self.p1)

        self.game.change_player()
        self.assertEqual(self.game.current_player, self.p2)

        self.game.change_player()
        self.assertEqual(self.game.current_player, self.p1)

    def test_game_states(self):
        self.assertFalse(self.game.has_started)
        self.assertFalse(self.game.has_finished)

    def test_get_printable_state(self):
        p1 = Player(hp=10, mana=5)
        p2 = Player(hp=12, mana=8)
        game = Game(p1, p2)

        lines = game.get_printable_state().split("\n")
        self.assertEqual(lines[0], "P1: 10/%s | M: 5/%s" % (const.PLAYER_HERO_HP_INIT, const.PLAYER_MANA_MAX))
        self.assertEqual(lines[1], "===================")
        self.assertEqual(lines[2], "-------------------")
        self.assertEqual(lines[3], "===================")
        self.assertEqual(lines[4], "P2: 12/%s | M: 8/%s" % (const.PLAYER_HERO_HP_INIT, const.PLAYER_MANA_MAX))
