import unittest

import game.const as const
from game.Player import Player


class PlayerTestCase(unittest.TestCase):
    def test_damage(self):
        player = Player(hp=const.PLAYER_HERO_HP_INIT + 5)

        player.damage(5)
        self.assertEqual(player.hp(), const.PLAYER_HERO_HP_INIT)

        player.damage(const.PLAYER_HERO_HP_INIT + 1)
        self.assertEqual(player.hp(), 0)

    def test_heal(self):
        player = Player(hp=const.PLAYER_HERO_HP_MAX - 5)

        player.heal(5)
        self.assertEqual(player.hp(), const.PLAYER_HERO_HP_MAX)

        player.heal(1)
        self.assertEqual(player.hp(), const.PLAYER_HERO_HP_MAX)
