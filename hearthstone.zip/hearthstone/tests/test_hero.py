import unittest

import game.const as const
from game.Hero import Hero


class HeroTestCase(unittest.TestCase):
    def test_damage(self):
        hero = Hero(hp=const.PLAYER_HERO_HP_INIT + 5)

        hero.damage(5)
        self.assertEqual(hero.hp, const.PLAYER_HERO_HP_INIT)

        hero.damage(const.PLAYER_HERO_HP_INIT + 1)
        self.assertEqual(hero.hp, 0)

    def test_heal(self):
        hero = Hero(hp=const.PLAYER_HERO_HP_MAX - 5)

        hero.heal(5)
        self.assertEqual(hero.hp, const.PLAYER_HERO_HP_MAX)

        hero.heal(1)
        self.assertEqual(hero.hp, const.PLAYER_HERO_HP_MAX)
