import unittest

from game import const as const
from game.card.Minion import Minion
from game.Deck import Deck


class DeckTestCase(unittest.TestCase):
    def test_init(self):
        deck = Deck()
        self.assertEqual(deck.cards, [])

    def test_random(self):
        deck = Deck.random()
        self.assertEqual(len(deck.cards), const.DECK_CARDS_NUMBER)

    def test_draw_card(self):
        deck = Deck.random(minions_number=1, spells_number=0)
        self.assertIsNotNone(deck.draw_card())
        self.assertIsNotNone(deck.draw_card())
        self.assertIsNone(deck.draw_card())

    def test_is_empty(self):
        deck = Deck()
        self.assertTrue(deck.is_empty())

        deck.cards.append(Minion.random())
        self.assertFalse(deck.is_empty())
