import random
import numpy as np
from game import const as const
from game.card.Minion import Minion
from game.card.spells.SpellDamage import SpellDamage
from game.card.spells.SpellDraw import SpellDraw
from game.card.spells.SpellHeal import SpellHeal


class Deck:
    def __init__(self, cards=None):
        np.random.seed(123)

        self.cards = cards or []

    @staticmethod
    def random(minions_number=const.HALF_DECK_MINIONS_NUMBER,
               spells_damage_number=const.HALF_DECK_DAMAGE_SPELLS_NUMBER,
               spells_heal_number=const.HALF_DECK_HEAL_SPELLS_NUMBER,
               spells_draw_number=const.HALF_DECK_DRAW_SPELLS_NUMBER):
        minions = []
        spells = []

        while len(minions) < minions_number:
            minions.append(Minion.random())

        while len(Deck.spells_of_type(spells, SpellDamage)) < spells_damage_number:
            spells.append(Deck.get_random_damage_spell())

        while len(Deck.spells_of_type(spells, SpellHeal)) < spells_heal_number:
            spells.append(Deck.get_random_heal_spell())

        while len(Deck.spells_of_type(spells, SpellDraw)) < spells_draw_number:
            spells.append(Deck.get_random_draw_spell())

        minions = Deck.add_special_abilities(minions)

        duplicated_minions = [minion.duplicate() for minion in minions]
        duplicated_spells = [spells.duplicate() for spells in spells]

        cards = minions + duplicated_minions + spells + duplicated_spells
        return Deck(cards)

    @staticmethod
    def spells_of_type(spells, type):
        return [spells for spell in spells if isinstance(spell, type)]

    @staticmethod
    def add_special_abilities(minions):
        for i in range(const.MINION_SPECIAL_ABILITY_TAUNT_NUMBER):
            minions = Deck.set_special_ability(minions, const.MINION_SPECIAL_ABILITY_TAUNT)

        for i in range(const.MINION_SPECIAL_ABILITY_CHARGE_NUMBER):
            minions = Deck.set_special_ability(minions, const.MINION_SPECIAL_ABILITY_CHARGE)

        for i in range(const.MINION_SPECIAL_ABILITY_DIVINE_SHIELD_NUMBER):
            minions = Deck.set_special_ability(minions, const.MINION_SPECIAL_ABILITY_DIVINE_SHIELD)

        return minions

    @staticmethod
    def set_special_ability(minions, special_ability):
        minion = Deck.get_minion_without_ability(minions)
        if minion:
            minion_index = minions.index(minion)
            minions[minion_index].set_special_ability(special_ability)
        return minions

    @staticmethod
    def get_minion_without_ability(minions):
        return next(filter(lambda m: m.special_ability is None, minions), None)

    @staticmethod
    def get_random_damage_spell():
        return SpellDamage.random()

    @staticmethod
    def get_random_heal_spell():
        return SpellHeal.random()

    @staticmethod
    def get_random_draw_spell():
        return SpellDraw.random()

    def duplicate(self):
        return Deck(list(self.cards))

    def draw_card(self):
        if self.cards:
            return self.cards.pop()
        return None

    def shuffle(self):
        if self.cards:
            random.shuffle(self.cards)

    def is_empty(self):
        return not self.cards
