from game import const


class Hero:
    def __init__(self, hp=const.PLAYER_HERO_HP_INIT):
        self.hp = hp

    def __str__(self):
        return "[Hero] (hp: %s)" % self.hp

    def damage(self, damage_hp):
        self.hp = max(self.hp - damage_hp, 0)

    def heal(self, heal_hp):
        self.hp = min(self.hp + heal_hp, const.PLAYER_HERO_HP_MAX)

    def is_alive(self):
        return self.hp > 0

    def is_dead(self):
        return self.hp <= 0
