from game.Move import Move
from game.TurnMove import TurnMove
import game.const as const


class Node:
    def __init__(self, state, depth=None, parent=None, trials_success=None, trials_total=None):
        self.state = state
        self.depth = depth
        self.parent = parent

        self.children = []
        self.turn_move = TurnMove()

        self.trials_success = trials_success or 0
        self.trials_total = trials_total or 0

        self.is_fully_expanded = False
        self.possible_moves = Move.get_possible_moves(state, is_mcts=True)
        self.next_move_index = 0

    def add_child(self, child_node):
        child_node.parent = self
        if not child_node.depth:
            child_node.depth = self.depth + 1
        self.children.append(child_node)

    def update(self, winner):
        is_mcts = self.state.current_player.strategy == const.PLAYER_STRATEGY_MCTS
        has_won = (winner is not None) and self.state.current_player.id == winner.id
        if is_mcts and has_won:
            self.trials_success += 1
        self.trials_total += 1

    def is_terminal(self):
        return self.state.has_finished

    def get_next_node_move(self):
        if self.next_move_index < len(self.possible_moves):
            self.next_move_index += 1
            return self.possible_moves[self.next_move_index - 1]
        return None

    def has_next_node_move(self):
        return self.next_move_index < len(self.possible_moves)

    def has_pass_move(self):
        for move in self.turn_move.moves:
            if move.action == move.PASS:
                return True
        return False
