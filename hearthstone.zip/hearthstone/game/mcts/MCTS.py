"""
Monte Carlo Tree Search (MCTS)
"""
import math

import time

import game.const as const
from game.Move import Move
from game.TurnMove import TurnMove
from game.mcts.Node import Node


class MCTS:
    def __init__(self, root_state):
        self.root_state = root_state
        self.root_node = Node(root_state, depth=0)

        # Stats
        self.playouts_number = 0
        self.time = 0

    def get_next_move(self):
        start_time = time.time()

        while time.time() < start_time + const.MCTS_ITERATIONS_TIMEOUT:
            leaf_node = self.tree_policy(self.root_node)

            if not leaf_node:
                self.time = time.time() - start_time
                return TurnMove(moves=[Move(action=Move.PASS)])

            winner = self.default_policy(leaf_node)
            self.backup(leaf_node, winner)

        best_move_node = self.best_root_node_child(self.root_node)

        self.time = time.time() - start_time

        if best_move_node:
            return best_move_node.turn_move

        return TurnMove(moves=[Move(action=Move.PASS)])

    # Expansion + node leaf selection
    def tree_policy(self, node):
        if node.is_terminal():
            return node

        if node.is_fully_expanded:
            return self.best_child(node)

        return self.expand(node)

    def expand(self, node):
        if node.is_terminal():
            return node

        next_move = node.get_next_node_move()

        if next_move:
            # Depth expansion
            new_game_state = node.state.duplicate()
            new_game_state.make_single_move(next_move)

            if node is not self.root_node:
                new_game_state.next_turn()

            child_node = Node(new_game_state)
            child_node.turn_move.add_move(next_move)
            node.add_child(child_node)
            return child_node

        else:
            # Right (same level/depth) expansion
            for parent in node.children:
                child_next_move = parent.get_next_node_move()

                if child_next_move:
                    new_state = parent.state.duplicate()
                    new_state.make_single_move(child_next_move)

                    child = Node(new_state)
                    child.turn_move.add_moves(parent.turn_move.moves)
                    child.turn_move.add_move(child_next_move)
                    node.add_child(child)
                    return child

        node.is_fully_expanded = True
        return self.best_child(node)

    @staticmethod
    def best_child(node, exploration_constant=const.MCTS_EXPLORATION_CONSTANT):
        best_child_node = None
        best_score = None

        for child in node.children:
            q = child.trials_success
            n = child.trials_total
            c = exploration_constant

            if n <= 0:
                best_child_node = child
                break

            parent_n = node.trials_total
            assert (parent_n > 0)

            score = q / n + c * math.sqrt(2 * math.log(parent_n) / n)

            if not best_score or score > best_score:
                best_child_node = child
                best_score = score

        return best_child_node

    @staticmethod
    def best_root_node_child(node):
        best_child_node = None
        best_score = None

        for child in node.children:
            q = child.trials_success
            n = child.trials_total

            if n <= 0:
                continue

            score = q / n

            if not best_score or score > best_score:
                best_child_node = child
                best_score = score

        return best_child_node

    # Run playout (simulation) and return a winner (as a reward)
    def default_policy(self, leaf_node):
        new_state = leaf_node.state.duplicate()

        new_state.p1.strategy = const.PLAYER_STRATEGY_AGENT_RANDOM
        new_state.p2.strategy = const.PLAYER_STRATEGY_AGENT_RANDOM

        while not new_state.has_finished:
            self.playouts_number += 1
            new_state.next_move()

        return new_state.winner

    def backup(self, node, winner):
        while node is not None:
            node.update(winner)
            node = node.parent
