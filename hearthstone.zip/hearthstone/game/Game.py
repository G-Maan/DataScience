import copy
import secrets
import uuid

import game.const as const
from game.Hero import Hero
from game.Move import Move
from game.Stats import print_mcts_stats
from game.Player import Player
from game.TurnMove import TurnMove
from game.card.Minion import Minion
from game.card.spells.SpellDraw import SpellDraw
from game.card.spells.SpellHeal import SpellHeal
from game.mcts.MCTS import MCTS


class Game:
    def __init__(self, player1, player2):
        self.id = const.MAIN_GAME_ID

        self.p1 = player1
        self.p2 = player2

        self.p1.id = const.PLAYER_1_ID
        self.p2.id = const.PLAYER_2_ID

        # Game states
        self.has_started = False
        self.has_finished = False

        # Initialised later
        self.current_player = None
        self.opponent = None
        self.current_turn = 1

        self.winner = None

    def duplicate(self):
        game = copy.deepcopy(self)
        game.id = uuid.uuid4()
        return game

    def start(self):
        """Start game and play until it is over"""
        print("GAME STATUS: started")

        self.has_started = True
        self.current_player = self.p1
        self.opponent = self.p2

        # self.p1.mana = 10
        # self.p1.current_mana = 10

        self.p2.mana = 0
        self.p2.current_mana = 0

        self.p1.draw_cards(const.PLAYER_1_CARDS_HAND_START)
        self.p2.draw_cards(const.PLAYER_2_CARDS_HAND_START)

        while not self.has_finished:
            self.next_move()

    def make_single_move(self, move):
        self.current_player.make_move(move)
        self.current_player.remove_dead_minions()
        self.opponent.remove_dead_minions()
        self.update_game_status()

    def next_move(self):
        if self.id == const.MAIN_GAME_ID:
            print("\n--- TURN: %s ---" % ((self.current_turn + 1) // 2))
            self.current_turn += 1

        player_id = 1 if self.current_player == self.p1 else 2
        if self.id == const.MAIN_GAME_ID:
            self.current_player.print_current_status(player_id)

        end_turn = False

        while not end_turn and not self.has_finished:
            next_move = self.get_next_move()

            if isinstance(next_move, TurnMove):
                self.__log("\nTurn move:")
                for move in next_move.moves:
                    self.__log("  -%s" % move)
                    self.make_single_move(move)
                    end_turn = True
            else:
                self.__log("\nSingle move:")
                self.__log("  -%s" % next_move)
                self.make_single_move(next_move)
                end_turn = next_move is None or next_move.is_pass()

        self.next_turn()

    def __log(self, message):
        if self.id == const.MAIN_GAME_ID:
            print(message)

    def next_turn(self):
        """Change player and make a move"""
        self.change_player()
        self.awake_player_board_cards()
        self.current_player.draw_card()
        self.current_player.increase_mana()
        self.current_player.fill_mana()

    def has_current_player_won(self):
        return self.current_player.is_alive() and self.opponent.is_dead()

    def update_game_status(self):
        if self.p1.is_alive() and self.p2.is_dead():
            self.__log("P1 has won the game!")
            self.winner = self.p1
            self.has_finished = True
        elif self.p1.is_dead() and self.p2.is_alive():
            self.__log("P2 has won the game!")
            self.winner = self.p2
            self.has_finished = True
        elif self.p1.is_dead() and self.p2.is_dead():
            self.__log("The game ends with a draw as both players are dead.")
            self.has_finished = True

    def get_next_move(self):
        strategy = self.current_player.strategy
        move = None

        if strategy == const.PLAYER_STRATEGY_MCTS:
            mcts = MCTS(self.duplicate())
            next_moves = mcts.get_next_move()
            print_mcts_stats(mcts)

            for next_move in next_moves.moves:
                if next_move.target is None:
                    continue

                if isinstance(next_move.card, SpellDraw):
                    next_move.target = self.current_player
                elif isinstance(next_move.card, SpellHeal):
                    if not isinstance(next_move.target, Minion):
                        next_move.target = self.current_player.hero
                elif isinstance(next_move.target, Hero):
                    if isinstance(next_move.card, SpellHeal):
                        next_move.target = self.current_player.hero
                    else:
                        next_move.target = self.opponent.hero
                else:
                    opponent_minions = self.opponent.get_minions(self.opponent.cards_board)
                    org_minion = next(filter(lambda c: c.is_same_card(next_move.target), opponent_minions), None)
                    next_move.target = org_minion

            return next_moves

        else:
            possible_moves = Move.get_player_possible_moves(self.current_player, self.opponent)

            if possible_moves:
                if strategy == const.PLAYER_STRATEGY_AGENT_OFFENSIVE:
                    move = Game.pick_offensive_move(possible_moves)

                elif strategy == const.PLAYER_STRATEGY_AGENT_DEFENSIVE:
                    move = Game.pick_defensive_move(possible_moves)

                elif strategy == const.PLAYER_STRATEGY_AGENT_RANDOM:
                    move = Game.pick_random_move(possible_moves)

                if isinstance(move.target, Player):
                    if isinstance(move.card, SpellDraw):
                        move.target = self.current_player

        return move

    @staticmethod
    def pick_offensive_move(moves):
        hero_targets = list(filter(lambda move: isinstance(move.target, Hero), moves))
        if hero_targets:
            return secrets.choice(hero_targets)
        cards_hand = list(filter(lambda move: move.action is not move.PASS, moves))
        if cards_hand:
            return secrets.choice(cards_hand)
        return Move(action=Move.PASS)

    @staticmethod
    def pick_defensive_move(moves):
        minion_targets = list(filter(lambda move: isinstance(move.target, Minion), moves))
        if minion_targets:
            return secrets.choice(minion_targets)
        cards_hand = list(filter(lambda move: move.action is not move.PASS, moves))
        if cards_hand:
            return secrets.choice(cards_hand)
        return Move(action=Move.PASS)

    @staticmethod
    def pick_random_move(moves):
        return secrets.choice(moves)

    def change_player(self):
        """Set current player as the next player"""
        if self.current_player is self.p1:
            self.current_player = self.p2
            self.opponent = self.p1
        else:
            self.current_player = self.p1
            self.opponent = self.p2

    def awake_player_board_cards(self):
        """Awake all of the player's minions that are on the board"""
        for card_minion in self.current_player.cards_board:
            card_minion.awake()

    def get_printable_state(self):
        lines = ["P1: %d/%d | M: %d/%d" % (self.p1.hp(), const.PLAYER_HERO_HP_INIT, self.p1.mana, const.PLAYER_MANA_MAX),
                 "=" * 19,
                 "-" * 19,
                 "=" * 19,
                 "P2: %d/%d | M: %d/%d" % (self.p2.hp(), const.PLAYER_HERO_HP_INIT, self.p2.mana, const.PLAYER_MANA_MAX)]
        return "\n".join(lines)
