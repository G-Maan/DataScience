import json

from game.mcts.MCTS import MCTS


def serialize(obj):
    if isinstance(obj, MCTS):
        res = []
        process_node(obj.root_node, res)
        return res

    return obj.__dict__


def process_node(node, res):
    res.append(node.depth)
    for child in node.children:
        print(child.depth)
        process_node(child, res)


def draw_mcts(mcts):
    for child in mcts.root_node.children:
        print(child)

    x = json.dumps(mcts, default=serialize)
    print(x)


def print_mcts_stats(mcts):
    print("\nPlayouts number:", mcts.playouts_number)
    print("Time:", mcts.time)
