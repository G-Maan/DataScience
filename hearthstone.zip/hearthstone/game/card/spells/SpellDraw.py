import random
import uuid

from game import const as const
from game.card.Spell import Spell

"""
Spell Draw

Description:
    Draws specified number of cards.

To be used on: 
    Player
"""


class SpellDraw(Spell):
    def __init__(self, cost, draw_amount):
        super().__init__(cost)

        self.id = uuid.uuid4()
        self.draw_amount = draw_amount

    def __str__(self):
        return "[S_DR] (C: %s DR: %s)" % (self.cost, self.draw_amount)

    @staticmethod
    def random():
        cost = random.randint(const.CARD_COST_MIN, const.CARD_COST_MAX)
        draw_amount = random.randint(const.SPELL_DRAW_MIN, const.SPELL_DRAW_MAX)
        return SpellDraw(cost, draw_amount)

    def cast(self, target):
        target.draw_cards(self.draw_amount)

    def duplicate(self):
        return SpellDraw(self.cost, self.draw_amount)

    def is_same_card(self, card):
        if not isinstance(card, SpellDraw):
            return False

        return self.id == card.id
