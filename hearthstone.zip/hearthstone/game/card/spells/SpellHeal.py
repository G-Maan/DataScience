import random
import uuid

from game import const as const
from game.card.Spell import Spell

"""
Spell Heal

Description:
    Increases hp of selected target.

To be used on: 
    Player | Minion
"""


class SpellHeal(Spell):
    def __init__(self, cost, heal_hp):
        super().__init__(cost)

        self.id = uuid.uuid4()
        self.heal_hp = heal_hp

    def __str__(self):
        return "[S_H] (C: %s H: %s)" % (self.cost, self.heal_hp)

    @staticmethod
    def random():
        cost = random.randint(const.CARD_COST_MIN, const.CARD_COST_MAX)
        heal_hp = random.randint(const.SPELL_HEAL_MIN, const.SPELL_HEAL_MAX)
        return SpellHeal(cost, heal_hp)

    def cast(self, target):
        target.heal(self.heal_hp)

    def duplicate(self):
        return SpellHeal(self.cost, self.heal_hp)

    def is_same_card(self, card):
        if not isinstance(card, SpellHeal):
            return False

        return self.id == card.id
