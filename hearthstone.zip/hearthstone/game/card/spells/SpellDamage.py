import random
import uuid

from game import const as const
from game.card.Spell import Spell

"""
Spell Damage

Description:
    Decreases hp of selected target.

To be used on: 
    Player | Minion
"""


class SpellDamage(Spell):
    def __init__(self, cost, damage_hp):
        super().__init__(cost)

        self.id = uuid.uuid4()
        self.damage_hp = damage_hp

    def __str__(self):
        return "[S_DA] (C: %s D: %s)" % (self.cost, self.damage_hp)

    @staticmethod
    def random():
        cost = random.randint(const.CARD_COST_MIN, const.CARD_COST_MAX)
        damage_hp = random.randint(const.SPELL_DAMAGE_MIN, const.SPELL_DAMAGE_MAX)
        return SpellDamage(cost, damage_hp)

    def cast(self, target):
        target.damage(self.damage_hp)

    def duplicate(self):
        return SpellDamage(self.cost, self.damage_hp)

    def is_same_card(self, card):
        if not isinstance(card, SpellDamage):
            return False

        return self.id == card.id
