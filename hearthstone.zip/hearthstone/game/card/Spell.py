class Spell:
    def __init__(self, cost):
        self.cost = cost

    def __str__(self):
        return "[S] (C: %s)" % self.cost

    @staticmethod
    def random():
        raise NotImplementedError("Missing random function")
        pass

    def cast(self, *args):
        raise NotImplementedError("Missing cast function")
