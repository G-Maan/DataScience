import random
import uuid

from game import const as const


class Minion:
    def __init__(self, cost, attack, hp, special_ability=None):
        self.id = uuid.uuid4()
        self.cost = cost
        self.attack = attack
        self.current_hp = hp
        self.special_ability = special_ability

        # By default minion should be on hand
        self.is_on_board = False

        self.max_hp = hp

        # Minion is asleep for 1 round after being placed on the board
        self.is_awake = False

    def __str__(self):
        return "[M] (C: %s, A: %s, S: %s H: %s/%s)" % (self.cost, self.attack, self.special_ability, self.current_hp, self.max_hp)

    @staticmethod
    def random():
        cost = random.randint(const.CARD_COST_MIN, const.CARD_COST_MAX)
        attack = random.randint(const.MINION_ATTACK_MIN, const.MINION_ATTACK_MAX)
        hp = random.randint(const.MINION_HP_MIN, const.MINION_HP_MAX)
        return Minion(cost, attack, hp)

    def duplicate(self):
        return Minion(self.cost, self.attack, self.max_hp, self.special_ability)

    def damage(self, damage_hp):
        if self.special_ability is const.MINION_SPECIAL_ABILITY_DIVINE_SHIELD:
            self.special_ability = None
        else:
            self.current_hp = max(self.current_hp - damage_hp, 0)

    def heal(self, heal_hp):
        self.current_hp = min(self.current_hp + heal_hp, self.max_hp)

    def awake(self):
        self.is_awake = True

    def is_same_card(self, card):
        if not isinstance(card, Minion):
            return False

        return self.id == card.id

    def set_special_ability(self, special_ability):
        if self.special_ability:
            raise Exception('Special ability %s already exists, cannot override with %s' % (self.special_ability, special_ability))
        self.special_ability = special_ability

    def add_taunt(self):
        self.set_special_ability(const.MINION_SPECIAL_ABILITY_TAUNT)
        return self

    def add_charge(self):
        self.set_special_ability(const.MINION_SPECIAL_ABILITY_CHARGE)
        return self

    def add_divine_shield(self):
        self.set_special_ability(const.MINION_SPECIAL_ABILITY_DIVINE_SHIELD)
        return self
