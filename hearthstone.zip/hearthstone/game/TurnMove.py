from game.Move import Move


class TurnMove:
    def __init__(self, moves=None):
        self.moves = moves or []

    def add_moves(self, moves):
        for move in moves:
            self.add_move(move)

    def add_move(self, move):
        self.moves.append(move)

    @staticmethod
    def get_player_possible_moves(player, opponent):
        return Move.get_player_possible_moves(player, opponent)
