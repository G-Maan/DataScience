from game.Deck import Deck
from game.Game import Game
from game.Player import Player
import game.const as const


class Gameplay:
    @staticmethod
    def basic():
        deck1 = Deck.random()
        deck1.shuffle()
        deck2 = deck1.duplicate()
        deck2.shuffle()

        p1 = Player(deck=deck1)
        p2 = Player(deck=deck2)

        game = Game(p1, p2)
        game.start()

    @staticmethod
    def mcts():
        deck1 = Deck.random()
        deck1.shuffle()
        deck2 = deck1.duplicate()
        deck2.shuffle()

        p1 = Player(deck=deck1, strategy=const.PLAYER_STRATEGY_MCTS)
        p2 = Player(deck=deck2, strategy=const.PLAYER_STRATEGY_AGENT_DEFENSIVE)

        game = Game(p1, p2)
        game.start()
