from game.card.Minion import Minion
from game.card.spells.SpellDamage import SpellDamage
from game.card.spells.SpellDraw import SpellDraw
from game.card.spells.SpellHeal import SpellHeal
import game.const as const


class Move:
    ATTACK = 'attack'
    HEAL = 'heal'
    PASS = 'pass'
    DRAW = 'draw'
    DAMAGE = 'damage'
    PLAY = 'play'

    def __init__(self, card=None, target=None, action=None):
        self.card = card
        self.target = target
        self.action = action

    def __str__(self):
        return "[Move] (c: %s, t: %s, a: %s)" % (self.card, self.target, self.action)

    @staticmethod
    def get_possible_moves(game, is_mcts=False):
        return Move.get_player_possible_moves(game.current_player, game.opponent, is_mcts=is_mcts)

    @staticmethod
    def get_player_possible_moves(player, opponent, is_mcts=False):
        moves_hand = [Move(card) for card in player.playable_cards(player.cards_hand)]
        all_moves = []

        for move in moves_hand:
            card = move.card

            if isinstance(card, SpellDamage):
                for target in Move.get_player_spell_targets(opponent):
                    all_moves.append(Move(card, target, Move.DAMAGE))
            elif isinstance(card, SpellHeal):
                for target in Move.get_player_spell_targets(player):
                    all_moves.append(Move(card, target, Move.HEAL))
            elif isinstance(card, SpellDraw):
                all_moves.append(Move(card, player, Move.DRAW))
            elif isinstance(card, Minion):
                all_moves.append(Move(card, action=Move.PLAY))
            else:
                raise Exception('Unknown possible move.')

        playable_board_minions = player.playable_minions(player.cards_board)
        for minion in playable_board_minions:
            for target in Move.get_player_minion_targets(opponent):
                all_moves.append(Move(minion, target, Move.ATTACK))

        if not is_mcts:
            all_moves.append(Move(action=Move.PASS))

        return all_moves

    @staticmethod
    def get_player_minion_targets(player):
        targets = []
        for minion in player.cards_board:
            targets.append(minion)

        targets_taunt = [target for target in targets if target.special_ability is const.MINION_SPECIAL_ABILITY_TAUNT]

        if targets_taunt:
            targets = targets_taunt

        if not targets_taunt:
            targets.append(player.hero)
        return targets

    @staticmethod
    def get_player_spell_targets(player):
        targets = []
        for minion in player.cards_board:
            targets.append(minion)

        targets.append(player.hero)
        return targets

    def is_pass(self):
        return self.action is Move.PASS
