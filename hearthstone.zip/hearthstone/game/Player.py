from game import const as const
from game.Hero import Hero
from game.Move import Move
from game.card.Minion import Minion
from game.card.Spell import Spell
from game.Deck import Deck
from game.card.spells.SpellDraw import SpellDraw
from game.card.spells.SpellHeal import SpellHeal


class Player:
    def __init__(self, hp=const.PLAYER_HERO_HP_INIT, mana=const.PLAYER_MANA_INIT, **kwargs):
        self.id = None
        self.hero = Hero(hp)
        self.mana = mana
        self.current_mana = mana
        self.deck = kwargs.get('deck', Deck.random())

        # Playing strategy to be used
        self.strategy = kwargs.get('strategy', const.PLAYER_STRATEGY_AGENT_OFFENSIVE)

        # Cards drawn by the player
        self.cards_hand = kwargs.get('cards_hand', [])

        # Cards on the board played by the player
        self.cards_board = kwargs.get('cards_board', [])

        # Cards already used (minions & spells), not on the board anymore
        self.cards_graveyard = kwargs.get('cards_graveyard', [])

        self.overdrawn_cards_number = kwargs.get('overdrawn_cards_number', 0)

    def __str__(self):
        return self.hero.__str__()

    def make_move(self, move):
        if move is None:
            return

        if not isinstance(move, Move):
            raise Exception("Player's move must be an instance of Move class")

        if move.card:
            self.play_card(move.card, target=move.target)

    def playable_cards(self, cards):
        playable_cards = list(filter(lambda card: self.can_play_card(card.cost), cards))
        for playable_card in playable_cards:
            if isinstance(playable_card, Minion):
                if not self.__can_play_minion():
                    playable_cards.remove(playable_card)
        return playable_cards

    @staticmethod
    def playable_minions(cards):
        return list(filter(lambda minion: minion.is_awake, cards))

    @staticmethod
    def get_minions(cards):
        return list(filter(lambda card: isinstance(card, Minion), cards))

    @staticmethod
    def get_spells(cards):
        return list(filter(lambda card: isinstance(card, Spell), cards))

    def draw_card(self):
        drawn_card = self.deck.draw_card()

        if not drawn_card:
            self.overdrawn_cards_number += 1
            self.damage(self.overdrawn_cards_number)
        else:
            if self.has_full_hand():
                self.cards_graveyard.append(drawn_card)
            else:
                self.cards_hand.append(drawn_card)

    def draw_cards(self, cards_number):
        for _ in range(cards_number):
            self.draw_card()

    def play_card(self, card, **kwargs):
        found_card_on_board = next(filter(lambda c: c.is_same_card(card) and c.is_awake, self.cards_board), None)

        if found_card_on_board:
            card = found_card_on_board
        else:
            card = next(filter(lambda c: c.is_same_card(card), self.cards_hand), None)

        if not card:
            raise Exception("The card hasn't been found")

        if card in self.cards_hand:

            if not self.can_play_card(card.cost):
                raise Exception("The card has too high cost and cannot be played")

            self.cards_hand.remove(card)
            self.use_mana(card)

            if isinstance(card, Minion):
                self.play_minion(card)
            elif isinstance(card, SpellDraw):
                self.draw_cards(cards_number=card.draw_amount)
                self.cards_graveyard.append(card)
            elif isinstance(card, Spell):
                self.play_spell(card, kwargs.get('target'))
                self.cards_graveyard.append(card)
        elif card in self.cards_board:
            self.attack_with_minion(card, kwargs.get('target'))
        else:
            raise Exception('Card not in players possession.')

    def use_mana(self, card):
        self.current_mana -= card.cost

        if self.current_mana < 0:
            raise Exception("Tried to use card that exceeds current mana.")

    @staticmethod
    def attack_with_minion(minion, target):
        if minion.is_awake:
            target.damage(minion.attack)
            if isinstance(target, Minion):
                minion.damage(target.attack)
            minion.is_awake = False
        else:
            raise Exception('Invalid move, minion %s is not awake', minion)

    def can_play_card(self, card_cost):
        return card_cost <= self.current_mana

    def increase_mana(self):
        if self.mana < const.PLAYER_MANA_MAX:
            self.mana += 1

    def fill_mana(self):
        self.current_mana = self.mana

    @staticmethod
    def play_spell(spell, target):
        spell.cast(target)

    def play_minion(self, minion):
        if self.__can_play_minion():
            if minion.special_ability is const.MINION_SPECIAL_ABILITY_CHARGE:
                minion.awake()
            minion.is_on_board = True
            self.cards_board.append(minion)
        else:
            self.cards_graveyard.append(minion)

    def remove_dead_minions(self):
        self.cards_board = [minion for minion in self.cards_board if minion.current_hp > 0]

    def __can_play_minion(self):
        return len(self.cards_board) < const.PLAYER_CARDS_BOARD_LIMIT

    def damage(self, damage_hp):
        self.hero.damage(damage_hp)

    def heal(self, heal_hp):
        self.hero.heal(heal_hp)

    def has_full_hand(self):
        return len(self.cards_hand) >= const.PLAYER_CARDS_HAND_LIMIT

    def hp(self):
        return self.hero.hp

    def is_alive(self):
        return self.hero.is_alive()

    def is_dead(self):
        return self.hero.is_dead()

    def print_current_status(self, player_id):
        print("\nPLAYER: %s (%s)\nHP: %s, MANA: %s\n# # # # #" % (player_id, self.strategy, self.hero.hp, self.current_mana))

        print("- cards_hand:")
        for card in self.cards_hand:
            print(card)

        print("- cards_board:")
        for card in self.cards_board:
            print(card)

        print("- graveyard:")
        for card in self.cards_graveyard:
            print(card)
