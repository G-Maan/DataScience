from data.scripts.json_io import JsonIO

DATASET_PATH = 'data/cards.json'
OUTPUT_FILE_PATH = 'data/spells.json'

if __name__ == "__main__":
    cards = JsonIO.load(DATASET_PATH)
    minions = list(filter(lambda card: 'type' in card and card['type'] == "SPELL", cards))
    JsonIO.save(minions, OUTPUT_FILE_PATH)
