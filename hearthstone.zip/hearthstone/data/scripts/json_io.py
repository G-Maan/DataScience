import json


class JsonIO:
    @staticmethod
    def load(input_file_path):
        with open(input_file_path) as data_file:
            data = json.load(data_file)
        return data

    @staticmethod
    def save(data, output_file_path):
        with open(output_file_path, 'w') as file:
            json.dump(data, file)
