from game.Gameplay import Gameplay


def run_game():
    # for i in range(100):
    #     Gameplay.basic()
    Gameplay.mcts()


if __name__ == "__main__":
    run_game()
