# Hearthstone

The analysis of Monte Carlo Tree Search (MCTS) based on a simplified implementation of a popular card video game called _Hearthstone_.

Getting started
---
Run the game:
```python3
python3 run_game.py
```

Tests
---

Run all the tests at once:
```python3
python3 -m unittest discover tests
``` 

Run a specific test case:
```python3
python3 -m unittest tests.test_file_name
``` 

Data
---
The cards dataset (`data/cards.json`) has been downloaded from [HearthstoneJSON.com](https://hearthstonejson.com)

Extract **spell** cards (`data/spells.json`):
```python3
python3 -m data.scripts.extract_spells
```

Extract **minion** cards (`data/minions.json`):
```python3
python3 -m data.scripts.extract_minions
```
